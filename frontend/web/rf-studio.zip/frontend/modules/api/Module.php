<?php

namespace frontend\modules\api;

class Module extends \yii\base\Module
{
    public function init()
    {
        parent::init();
    }
}
