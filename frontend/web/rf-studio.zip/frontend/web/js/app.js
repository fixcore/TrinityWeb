$(document).ready(function() {
    $(function () {$('.tltp').tooltip({animation: false})});
});